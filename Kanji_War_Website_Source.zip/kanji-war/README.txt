KANJI WAR — WEBSITE SOURCE
1) Mở https://github.com và đăng nhập/tạo tài khoản.
2) Nhấn New repository, đặt tên kanji-war, chọn Public, Create repository.
3) Add file > Upload files, kéo index.html vào, Commit changes.
4) Settings > Pages > Build and deployment: Deploy from a branch; chọn main / root; Save.
5) Chờ GitHub Pages tạo URL dạng https://TEN-TK.github.io/kanji-war/
Lưu ý: Đây là prototype frontend, chơi luân phiên 2 người trên cùng máy; chưa có chơi online nhiều máy/AI.
